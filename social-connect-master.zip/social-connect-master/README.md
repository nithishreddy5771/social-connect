# social-connect
Simple social networking kind of project with incremental feature addition.
Deploying features using DevOps tools.
